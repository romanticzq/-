package com.qingshixun.register;

import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.Preparable;

public class RegisterAction extends ActionSupport{

	//用户实体
	private User user;
	
	public void setUser(User user) {
		this.user = user;
	}
	
	public User getUser() {
		return user;
	}
	
	/**
	 * 进入注册页面
	 */
	public String register() {
		//在struts.xml文件中配置转向，跳转到：/WEB-INF/views/register。jsp
		return "success";
	}
	
	/**
	 * 保存页面
	 */
	public String save() {
		//接受前台传入的用户信息
		System.out.println(user);
		
		//保存完后跳转到注册结构页面
		//在Struts。xml文件中配置转向，跳转到：/WEB-INF/views/registerResult。jsp
		return "success";
	}
	
	
}
